package jp.main.taikun.mysticaleverything;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.material.Fluid;
import net.minecraftforge.fluids.FluidStack;
import net.minecraftforge.fluids.FluidType;

public class TagItemHelper {
    public static CompoundTag itemToTag(ItemStack stack) {
        if (stack.getCount() != 1) {
            stack = new ItemStack(stack.getItem());
        }
        CompoundTag itemTag = new CompoundTag();
        stack.save(itemTag);
        CompoundTag compoundTag = new CompoundTag();
        compoundTag.put("Item", itemTag);
        compoundTag.putString("type", "item");
        return compoundTag;
    }
    public static CompoundTag fluidToTag(Fluid fluid) {
        FluidStack fluidStack = new FluidStack(fluid, 1);
        CompoundTag fluidTag = new CompoundTag();
        fluidStack.writeToNBT(fluidTag);
        CompoundTag compoundTag = new CompoundTag();
        compoundTag.put("Fluid", fluidTag);
        compoundTag.putString("type", "fluid");
        return compoundTag;
    }
    public static CropResource tagToResource(CompoundTag compoundTag) {
        if (compoundTag == null) throw new IllegalArgumentException("compoundTag is null");
        if (!compoundTag.contains("type")) throw new IllegalArgumentException("compoundTag does not contain type");
        String type = compoundTag.getString("type");
        CropResource cropResource = null;
        switch (type) {
            case "item":
                if (compoundTag.contains("Item")) {
                    ItemStack itemStack = ItemStack.of(compoundTag.getCompound("Item"));
                    // if  (itemStack.getCount() != 1) throw new IllegalArgumentException("Item is invalid");
                    cropResource = new CropResource(itemStack);
                } else {
                    throw new IllegalArgumentException("compoundTag does not contain item");
                }
                break;

                case "fluid":
                    if (compoundTag.contains("Fluid")) {
                        FluidStack fluidStack = FluidStack.loadFluidStackFromNBT(compoundTag.getCompound("Fluid"));
                        if (fluidStack.isEmpty()) throw new IllegalArgumentException("Fluid is invalid");
                        if (fluidStack.getAmount() != 1) throw new IllegalArgumentException("Fluid is invalid");
                        Fluid fluidType = fluidStack.getFluid();
                        cropResource = new CropResource(fluidType);
                    }
                    break;

            default:
                throw new IllegalArgumentException("type is not item or fluid");
        }
        return cropResource;
    }
    public static CropResource tagToResourceDirect(CompoundTag compoundTag) {
        if (compoundTag == null) return CropResource.EMPTY;
        if (!compoundTag.contains("resource")) return CropResource.EMPTY;
        CompoundTag resourceTag = compoundTag.getCompound("resource");
        return tagToResource(resourceTag);
    }
    public static CompoundTag resourceToTag(CropResource cropResource) {
        if (cropResource == null) throw new IllegalArgumentException("cropResource is null");
        return switch (cropResource.getType()) {
            case ITEM -> itemToTag(cropResource.getItem());
            case FLUID -> fluidToTag(cropResource.getFluid());
        };
    }
}
