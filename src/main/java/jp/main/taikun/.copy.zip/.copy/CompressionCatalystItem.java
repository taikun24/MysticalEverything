package jp.main.taikun.mysticaleverything;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import org.jetbrains.annotations.NotNull;

public class CompressionCatalystItem extends Item{
    public CompressionCatalystItem() {
        super(new Item.Properties().rarity(Rarity.UNCOMMON));
    }

    @Override
    public @NotNull Component getName(ItemStack stack) {
        CompoundTag tag = stack.getOrCreateTag();
        if (tag.isEmpty() || !tag.contains("resource")) return super.getName(stack);
        CropResource resource = TagItemHelper.tagToResource(tag.getCompound("resource"));
        if (resource == null) return super.getName(stack);
        return Component.translatable("item.mysticaleverything.compression_catalyst.compressed", resource.getName());
    }
    @Override
    public boolean isFoil(ItemStack stack) {
        return !(stack.getOrCreateTag().isEmpty() || stack.getOrCreateTag().contains("resource"));
    }
}
