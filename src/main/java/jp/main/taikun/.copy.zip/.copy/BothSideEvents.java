package jp.main.taikun.mysticaleverything;

import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.level.block.Blocks;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = Mysticaleverything.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class BothSideEvents {
    public static CreativeModeTab TAB;


}
