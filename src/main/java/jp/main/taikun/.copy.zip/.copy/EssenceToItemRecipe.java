package jp.main.taikun.mysticaleverything;

import net.minecraft.core.RegistryAccess;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.inventory.CraftingContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.CraftingBookCategory;
import net.minecraft.world.item.crafting.CustomRecipe;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.NotNull;

public class EssenceToItemRecipe extends CustomRecipe {
    public EssenceToItemRecipe(ResourceLocation p_252125_, CraftingBookCategory p_249010_) {
        super(p_252125_, p_249010_);
    }
    @Override
    public boolean matches(CraftingContainer container, Level level) {
        int count = 0; // 0からカウントを始める
        CompoundTag tag = null;

        for (int i = 0; i < container.getContainerSize(); i++) {
            ItemStack stack = container.getItem(i);

            if (!stack.isEmpty()) {
                // 指定のアイテムであるかチェック
                if (stack.is(Mysticaleverything.EVERYTHING_ESSENCE.get())) {
                    CompoundTag currentTag = stack.getTag(); // getOrCreateTag()よりgetTag()の方が安全

                    if (tag == null) {
                        tag = currentTag; // 最初に最初に見つかったタグを基準にする
                    } else {
                        // 2つ目以降のアイテムのタグが、1つ目と「一致していなければ」クラフト失敗
                        if (!tag.equals(currentTag)) {
                            return false;
                        }
                    }
                    count++;
                } else {
                    // 関係ないアイテムが入っていたら即座に失敗
                    return false;
                }
            }
        }

        // 例: 9個ぴったり配置されていて、かつタグが存在している場合のみ成功
        // もし1個でもクラフト可能にしたい場合は「count > 0」などに変更してください
        return count == 9 && tag != null;
    }

    @Override
    public @NotNull ItemStack assemble(CraftingContainer container, @NotNull RegistryAccess registryAccess) {
        CompoundTag tag = null;
        for (int i = 0; i < container.getContainerSize(); i++) {
            ItemStack stack = container.getItem(i);
            if (!stack.isEmpty() && stack.is(Mysticaleverything.EVERYTHING_ESSENCE.get())) {
                tag = stack.getTag();
                break;
            }
        }

        if (tag == null) return ItemStack.EMPTY;

        CompoundTag resourceTag = tag.getCompound("resource");
        if (resourceTag.isEmpty()) return ItemStack.EMPTY;
        CropResource crop = TagItemHelper.tagToResource(resourceTag);
        if (crop == null || crop.getType() != CropResource.TYPE.ITEM) return ItemStack.EMPTY;

        ItemStack output = crop.getItem().copy();
        // 必要に応じて output.setCount(1); などを設定
        return output;
    }
    @Override
    public boolean canCraftInDimensions(int width, int height) {
        return width * height >= 1;
    }

    @Override
    public @NotNull RecipeSerializer<?> getSerializer() {
        return Mysticaleverything.ESSENCE_TO_ITEM_RECIPE_SERIALIZER.get();
    }
}
