package jp.main.taikun.mysticaleverything;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.network.chat.Component;
public class CropResource {
    public enum TYPE{
        ITEM, FLUID
    }
    public static final CropResource EMPTY = new CropResource(new ItemStack(net.minecraft.world.item.Items.AIR, 1));
    private final TYPE type;
    private ItemStack item;
    private Fluid fluid;

    public CropResource(ItemStack item) {
        this.type = TYPE.ITEM;
        this.item = item;
    }
    public CropResource(Fluid stack) {
        this.type = TYPE.FLUID;
        this.fluid = stack;
    }

    public TYPE getType() {
        return type;
    }

    public ItemStack getItem() {
        if (type !=  TYPE.ITEM) throw new IllegalArgumentException("type is not ITEM");
        return item;
    }
    public Fluid getFluid() {
        if  (type !=  TYPE.FLUID) throw new IllegalArgumentException("type is not FLUID");
        return fluid;
    }

    public Component getName() {
        return switch (type) {
            case ITEM -> item==null ? Component.literal("error") : item.getHoverName();
            case FLUID -> Component.literal("Fluid (Temp Name)");
        };
    }
}
